<?php $__env->startSection('title', 'Tokoooo'); ?>
<?php $__env->startSection('content'); ?>
<div class ="card">
    <div class ="card-body">
        <h3>nama : <?php echo e($item['nama']); ?></h3>
        <h3>gambar : <?php echo e($item['gambar']); ?></h3>
        <h3>harga : <?php echo e($item['harga']); ?></h3>
        <h3>stok : <?php echo e($item['stok']); ?></h3>
        <h3>ukuran : <?php echo e($item['ukuran']); ?></h3>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatu\resources\views/items/show.blade.php ENDPATH**/ ?>